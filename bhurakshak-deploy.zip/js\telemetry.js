/**
 * BhuRakshak IoT Telemetry Simulator & Live Charting Engine
 * Smart India Hackathon 2026 - Problem Statement 26001
 * 
 * Simulates LoRaWAN low-power edge sensor nodes deployed across remote NER hill slopes.
 * Feeds real-time time-series data into Chart.js dashboards.
 */

const TelemetryManager = (function () {
  let isRunning = true;
  let timerId = null;
  let activeHotspotId = "NER-EKH-01"; // Default: Cherrapunji / Sohra
  
  // Stored historical timeline (last 12 readings)
  const historyData = {
    timestamps: [],
    rainfall: [],
    soilMoisture: [],
    tilt: [],
    porePressure: []
  };

  let chartRainfall = null;
  let chartGeotech = null;

  // Initialize rolling timeline
  function initHistory() {
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const past = new Date(now.getTime() - i * 15 * 60 * 1000);
      const timeStr = past.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      historyData.timestamps.push(timeStr);
      
      // Base historical curve
      const factor = 1 - (i / 15);
      historyData.rainfall.push(parseFloat((35 + factor * 45 + (Math.random() * 8 - 4)).toFixed(1)));
      historyData.soilMoisture.push(parseFloat((62 + factor * 22 + (Math.random() * 4 - 2)).toFixed(1)));
      historyData.tilt.push(parseFloat((1.5 + factor * 2.8 + (Math.random() * 0.4 - 0.2)).toFixed(2)));
      historyData.porePressure.push(parseFloat((20 + factor * 20 + (Math.random() * 3 - 1.5)).toFixed(1)));
    }
  }

  function initCharts() {
    initHistory();

    const ctxRain = document.getElementById('telemetry-rain-chart');
    if (ctxRain) {
      chartRainfall = new Chart(ctxRain, {
        type: 'line',
        data: {
          labels: historyData.timestamps,
          datasets: [
            {
              label: 'Rainfall Rate (mm/h)',
              data: historyData.rainfall,
              borderColor: '#38bdf8',
              backgroundColor: 'rgba(56, 189, 248, 0.15)',
              borderWidth: 2,
              fill: true,
              tension: 0.35,
              pointRadius: 3,
              pointBackgroundColor: '#38bdf8'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { labels: { color: '#94a3b8', font: { family: 'Inter', size: 11 } } },
            tooltip: { mode: 'index', intersect: false }
          },
          scales: {
            x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#64748b', font: { size: 10 } } },
            y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#64748b', font: { size: 10 } }, min: 0 }
          }
        }
      });
    }

    const ctxGeo = document.getElementById('telemetry-geotech-chart');
    if (ctxGeo) {
      chartGeotech = new Chart(ctxGeo, {
        type: 'line',
        data: {
          labels: historyData.timestamps,
          datasets: [
            {
              label: 'Soil Moisture (%)',
              data: historyData.soilMoisture,
              borderColor: '#10b981',
              backgroundColor: 'transparent',
              borderWidth: 2,
              tension: 0.35,
              pointRadius: 2,
              yAxisID: 'y'
            },
            {
              label: 'Inclinometer Tilt (°)',
              data: historyData.tilt,
              borderColor: '#f97316',
              backgroundColor: 'transparent',
              borderWidth: 2,
              tension: 0.35,
              pointRadius: 2,
              yAxisID: 'y1'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { labels: { color: '#94a3b8', font: { family: 'Inter', size: 11 } } }
          },
          scales: {
            x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#64748b', font: { size: 10 } } },
            y: {
              type: 'linear',
              display: true,
              position: 'left',
              grid: { color: 'rgba(255,255,255,0.05)' },
              ticks: { color: '#10b981', font: { size: 10 } },
              title: { display: true, text: 'Moisture %', color: '#10b981', font: { size: 10 } }
            },
            y1: {
              type: 'linear',
              display: true,
              position: 'right',
              grid: { drawOnChartArea: false },
              ticks: { color: '#f97316', font: { size: 10 } },
              title: { display: true, text: 'Tilt (°)', color: '#f97316', font: { size: 10 } }
            }
          }
        }
      });
    }

    startTelemetryStream();
  }

  function pushNewReading(rainOverride = null, moistureOverride = null, tiltOverride = null) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    // Previous values
    const lastRain = historyData.rainfall[historyData.rainfall.length - 1];
    const lastMoist = historyData.soilMoisture[historyData.soilMoisture.length - 1];
    const lastTilt = historyData.tilt[historyData.tilt.length - 1];
    const lastPore = historyData.porePressure[historyData.porePressure.length - 1];

    // Compute next realistic values
    const newRain = rainOverride !== null ? rainOverride : Math.max(5, parseFloat((lastRain + (Math.random() * 4 - 2)).toFixed(1)));
    const newMoist = moistureOverride !== null ? moistureOverride : Math.min(98, Math.max(30, parseFloat((lastMoist + (newRain > 40 ? 0.3 : -0.2) + (Math.random() * 0.4 - 0.2)).toFixed(1))));
    const newTilt = tiltOverride !== null ? tiltOverride : Math.min(8.5, Math.max(0.5, parseFloat((lastTilt + (newMoist > 80 ? 0.05 : 0.0) + (Math.random() * 0.04 - 0.02)).toFixed(2))));
    const newPore = parseFloat((newMoist * 0.52 + Math.random() * 2).toFixed(1));

    // Shift rolling window (keep 15 readings)
    if (historyData.timestamps.length >= 15) {
      historyData.timestamps.shift();
      historyData.rainfall.shift();
      historyData.soilMoisture.shift();
      historyData.tilt.shift();
      historyData.porePressure.shift();
    }

    historyData.timestamps.push(timeStr);
    historyData.rainfall.push(newRain);
    historyData.soilMoisture.push(newMoist);
    historyData.tilt.push(newTilt);
    historyData.porePressure.push(newPore);

    if (chartRainfall) {
      chartRainfall.data.labels = historyData.timestamps;
      chartRainfall.data.datasets[0].data = historyData.rainfall;
      chartRainfall.update('none');
    }

    if (chartGeotech) {
      chartGeotech.data.labels = historyData.timestamps;
      chartGeotech.data.datasets[0].data = historyData.soilMoisture;
      chartGeotech.data.datasets[1].data = historyData.tilt;
      chartGeotech.update('none');
    }

    // Update digital gauge readings in DOM
    updateDigitalMeters(newRain, newMoist, newTilt, newPore);
    
    // Broadcast event for AI engine recalculation
    window.dispatchEvent(new CustomEvent('telemetry-updated', {
      detail: {
        rainfall: newRain,
        moisture: newMoist,
        tilt: newTilt,
        porePressure: newPore
      }
    }));
  }

  function updateDigitalMeters(rain, moist, tilt, pore) {
    const elRain = document.getElementById('meter-rainfall');
    const elMoist = document.getElementById('meter-moisture');
    const elTilt = document.getElementById('meter-tilt');
    const elPore = document.getElementById('meter-pore');

    if (elRain) elRain.textContent = rain.toFixed(1) + ' mm/h';
    if (elMoist) elMoist.textContent = moist.toFixed(1) + '%';
    if (elTilt) elTilt.textContent = tilt.toFixed(2) + '°';
    if (elPore) elPore.textContent = pore.toFixed(1) + ' kPa';
  }

  function startTelemetryStream() {
    if (timerId) clearInterval(timerId);
    timerId = setInterval(() => {
      if (isRunning) {
        pushNewReading();
      }
    }, 3500);
  }

  function toggleSimulation() {
    isRunning = !isRunning;
    return isRunning;
  }

  function triggerCloudburstEvent() {
    // Inject acute sudden storm readings
    pushNewReading(124.5, 94.8, 5.85);
  }

  function triggerDryWeatherEvent() {
    pushNewReading(4.2, 42.0, 1.15);
  }

  return {
    initCharts,
    pushNewReading,
    toggleSimulation,
    triggerCloudburstEvent,
    triggerDryWeatherEvent,
    isRunning: () => isRunning,
    getLatestReadings: () => ({
      rainfall: historyData.rainfall[historyData.rainfall.length - 1] || 82.0,
      moisture: historyData.soilMoisture[historyData.soilMoisture.length - 1] || 86.4,
      tilt: historyData.tilt[historyData.tilt.length - 1] || 4.25,
      porePressure: historyData.porePressure[historyData.porePressure.length - 1] || 41.5
    })
  };
})();

window.TelemetryManager = TelemetryManager;
