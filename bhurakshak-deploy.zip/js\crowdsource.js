/**
 * BhuRakshak Crowdsourced Field Incident & Verification Module
 * Smart India Hackathon 2026 - Problem Statement 26001
 * Team: Codebreakers | Organization: MDoNER & NDMA
 * 
 * Supports:
 * - Offline-first reporting with LocalStorage caching for low-connectivity hill terrain
 * - Network status simulation (Online 4G/5G, 2G Low Bandwidth, Offline Hill Mode)
 * - Synthetic computer vision crack detection and aperture measurement
 * - Instant GIS map synchronisation upon report validation
 */

const CrowdsourceManager = (function () {
  const STORAGE_KEY = 'bhurakshak_field_reports';
  const OUTBOX_KEY = 'bhurakshak_offline_outbox';
  
  let networkMode = 'online'; // 'online', 'low_bandwidth', 'offline'

  // Initial seed reports from recent NER field surveys
  const SEED_REPORTS = [
    {
      id: "RPT-2026-001",
      timestamp: "Today, 15:40",
      reporter: "Tenzing Lepcha (PWD Inspector)",
      role: "Official",
      location: "NH-10 km 38 (Near Teesta Bazaar)",
      lat: 27.0543,
      lng: 88.4985,
      type: "Tension Crack & Subsidence",
      severity: "CRITICAL",
      crackWidth: "35 cm",
      roadImpact: "Eastbound lane collapsed into gorge",
      status: "VERIFIED BY SDRF",
      photoUrl: "https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?w=500&auto=format&fit=crop&q=60",
      aiVisionConfidence: "96.4% Rock Slope Shear Failure (CV Class IV)"
    },
    {
      id: "RPT-2026-002",
      timestamp: "Today, 16:15",
      reporter: "Lalhmingliana (Aizawl Volunteer)",
      role: "Citizen",
      location: "Laipuitlang Hill Slope, Aizawl",
      lat: 23.7380,
      lng: 92.7210,
      type: "Water Seepage & Slump",
      severity: "WARNING",
      crackWidth: "12 cm",
      roadImpact: "Drainage overflow causing road scour",
      status: "PENDING VERIFICATION",
      photoUrl: "https://images.unsplash.com/photo-1547683905-f686c993aae5?w=500&auto=format&fit=crop&q=60",
      aiVisionConfidence: "84.1% Hydro-static Soil Creep (CV Class II)"
    },
    {
      id: "RPT-2026-003",
      timestamp: "Today, 17:02",
      reporter: "Kevichusa Angami (SDRF Kohima)",
      role: "SDRF",
      location: "Phesama Bypass NH-29",
      lat: 25.6421,
      lng: 94.1135,
      type: "Debris & Boulders on Tarmac",
      severity: "CRITICAL",
      crackWidth: "40 cm",
      roadImpact: "Complete traffic gridlock",
      status: "VERIFIED BY SDRF",
      photoUrl: "https://images.unsplash.com/photo-1508873696983-2df5703bc20d?w=500&auto=format&fit=crop&q=60",
      aiVisionConfidence: "98.2% Disang Shale Mass Wasting (CV Class V)"
    }
  ];

  // Reference benchmark field photographs for geotechnical calibration
  const SAMPLE_PHOTOS = {
    crack: {
      url: "https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?w=500&auto=format&fit=crop&q=60",
      type: "Tension Cracks on Hill Crest",
      crackWidth: "32 cm",
      severity: "CRITICAL",
      confidence: "96.8% Shear Fracture Surface",
      impact: "Crown scarp extending 15 meters along roadside"
    },
    rockfall: {
      url: "https://images.unsplash.com/photo-1508873696983-2df5703bc20d?w=500&auto=format&fit=crop&q=60",
      type: "Active Boulder Rolling / Rockfall",
      crackWidth: "48 cm detachment",
      severity: "CRITICAL",
      confidence: "98.4% Wedge Failure Geometry",
      impact: "Boulders >1.5m diameter obstructing carriage lane"
    },
    seepage: {
      url: "https://images.unsplash.com/photo-1547683905-f686c993aae5?w=500&auto=format&fit=crop&q=60",
      type: "Water Seepage & Muddy Springs",
      crackWidth: "14 cm piping",
      severity: "WARNING",
      confidence: "89.2% Subsurface Saturation Piping",
      impact: "Turbid spring erupting from road embankment toe"
    }
  };

  function getReports() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn("Storage read error:", e);
    }
    return SEED_REPORTS;
  }

  function saveReports(reports) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } catch (e) {
      console.warn("Storage write error:", e);
    }
  }

  function getOutbox() {
    try {
      const stored = localStorage.getItem(OUTBOX_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {}
    return [];
  }

  function saveOutbox(outbox) {
    try {
      localStorage.setItem(OUTBOX_KEY, JSON.stringify(outbox));
    } catch (e) {}
  }

  function setNetworkMode(mode) {
    networkMode = mode;
    const badge = document.getElementById('connectivity-badge');
    const outboxCountEl = document.getElementById('offline-queue-count');

    if (badge) {
      if (mode === 'online') {
        badge.className = 'bg-emerald-950 text-emerald-300 border border-emerald-800 px-2.5 py-1 rounded text-xs font-mono flex items-center';
        badge.innerHTML = '<span class="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span> Network: 4G/5G Online';
      } else if (mode === 'low_bandwidth') {
        badge.className = 'bg-amber-950 text-amber-300 border border-amber-800 px-2.5 py-1 rounded text-xs font-mono flex items-center';
        badge.innerHTML = '<span class="w-2 h-2 rounded-full bg-amber-400 mr-1.5"></span> Network: 2G Edge (Compressed)';
      } else {
        badge.className = 'bg-rose-950 text-rose-300 border border-rose-800 px-2.5 py-1 rounded text-xs font-mono flex items-center';
        badge.innerHTML = '<span class="w-2 h-2 rounded-full bg-rose-400 mr-1.5"></span> Hill Mode: Offline (Local Cache)';
      }
    }

    if (mode === 'online') {
      syncOfflineQueue();
    }

    updateOutboxUI();
  }

  function updateOutboxUI() {
    const outbox = getOutbox();
    const countEl = document.getElementById('offline-queue-count');
    const container = document.getElementById('offline-queue-container');

    if (countEl) countEl.textContent = outbox.length;
    if (container) {
      if (outbox.length > 0) {
        container.classList.remove('hidden');
      } else {
        container.classList.add('hidden');
      }
    }
  }

  function syncOfflineQueue() {
    const outbox = getOutbox();
    if (outbox.length === 0) return;

    const reports = getReports();
    outbox.forEach(item => {
      item.status = "SYNCED TO CLOUD (VERIFIED)";
      reports.unshift(item);
      window.dispatchEvent(new CustomEvent('new-field-report', { detail: item }));
    });

    saveReports(reports);
    saveOutbox([]);
    renderReportList();
    updateOutboxUI();

    if (window.App) {
      window.App.showNotificationToast(`⚡ Cloud Sync Complete: ${outbox.length} offline report(s) uploaded to MDoNER GIS server!`);
    }
  }

  function addReport(newReport) {
    const reports = getReports();
    const formatted = {
      id: "RPT-2026-" + String(reports.length + getOutbox().length + 1).padStart(3, '0'),
      timestamp: "Just Now",
      reporter: newReport.reporter || "Anonymous Field Officer",
      role: newReport.role || "Citizen",
      location: newReport.location || "NER Hill Slope Location",
      lat: parseFloat(newReport.lat) || 25.5788,
      lng: parseFloat(newReport.lng) || 91.8833,
      type: newReport.type || "Slope Instability",
      severity: newReport.severity || "WARNING",
      crackWidth: newReport.crackWidth || "15 cm",
      roadImpact: newReport.roadImpact || "Partial lane obstruction",
      status: networkMode === 'offline' ? "QUEUED OFFLINE (EDGE STORAGE)" : "SUBMITTED (AI ANALYZED)",
      photoUrl: newReport.photoUrl || "https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?w=500&auto=format&fit=crop&q=60",
      aiVisionConfidence: newReport.aiVisionConfidence || "92.4% Validated Geotechnical Anomaly"
    };

    if (networkMode === 'offline') {
      const outbox = getOutbox();
      outbox.push(formatted);
      saveOutbox(outbox);
      updateOutboxUI();
      if (window.App) {
        window.App.showNotificationToast(`Report saved locally in Offline Edge Cache. Will sync automatically upon reconnection!`);
      }
      return formatted;
    }

    reports.unshift(formatted);
    saveReports(reports);

    // Broadcast event so map adds marker immediately
    window.dispatchEvent(new CustomEvent('new-field-report', { detail: formatted }));

    return formatted;
  }

  function scanSamplePhoto(sampleKey) {
    const sample = SAMPLE_PHOTOS[sampleKey];
    if (!sample) return;

    // Update photo preview
    const previewImg = document.getElementById('report-photo-preview');
    const previewBox = document.getElementById('photo-preview-container');
    const scanBox = document.getElementById('cv-scan-result');
    const confText = document.getElementById('cv-confidence-text');

    if (previewImg) previewImg.src = sample.url;
    if (previewBox) previewBox.classList.remove('hidden');
    if (scanBox) scanBox.classList.remove('hidden');
    if (confText) confText.textContent = sample.confidence;

    // Auto-fill form values based on Computer Vision scan
    const typeSelect = document.getElementById('rpt-type');
    const crackInput = document.getElementById('rpt-crack');
    const sevSelect = document.getElementById('rpt-severity');
    const impactInput = document.getElementById('rpt-impact');

    if (typeSelect) typeSelect.value = sample.type;
    if (crackInput) crackInput.value = sample.crackWidth;
    if (sevSelect) sevSelect.value = sample.severity;
    if (impactInput) impactInput.value = sample.impact;

    if (window.App) {
      window.App.showNotificationToast(`AI Computer Vision Pre-Scan Complete: ${sample.confidence}`);
    }
  }

  function renderReportList(containerId = 'field-reports-container') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const reports = getReports();
    container.innerHTML = reports.map(r => {
      const isCrit = r.severity === 'CRITICAL';
      const badgeClass = isCrit ? 'badge-critical' : (r.severity === 'WARNING' ? 'badge-warning' : 'badge-watch');
      
      return `
        <div class="glass-panel p-3.5 mb-3 border-l-4 ${isCrit ? 'border-l-rose-500' : 'border-l-amber-500'} hover:border-cyan-400 transition-all">
          <div class="flex items-center justify-between mb-1.5">
            <span class="font-mono text-xs text-cyan-400 font-bold">${r.id}</span>
            <span class="${badgeClass} px-2 py-0.5 rounded text-[10px] font-semibold">${r.severity}</span>
          </div>
          <div class="font-semibold text-sm text-slate-100">${r.type}</div>
          <div class="text-xs text-slate-400 flex items-center mt-1">
            <i data-lucide="map-pin" class="w-3 h-3 mr-1 text-slate-500 inline"></i> ${r.location}
          </div>
          <div class="text-xs text-slate-400 flex items-center mt-0.5">
            <i data-lucide="user" class="w-3 h-3 mr-1 text-slate-500 inline"></i> ${r.reporter} (${r.role}) • <span class="text-slate-500 ml-1">${r.timestamp}</span>
          </div>
          <div class="mt-2 text-xs bg-slate-900/70 p-2 rounded border border-slate-800 text-slate-300">
            <span class="text-cyan-300 font-medium">Impact:</span> ${r.roadImpact} | <span class="text-amber-300 font-medium">Crack:</span> ${r.crackWidth}
          </div>
          <div class="mt-2 flex items-center justify-between text-[11px]">
            <span class="text-emerald-400 flex items-center font-medium"><i data-lucide="check-circle" class="w-3 h-3 mr-1"></i> ${r.status}</span>
            <span class="text-cyan-400/90 font-mono text-[10px]">${r.aiVisionConfidence}</span>
          </div>
        </div>
      `;
    }).join('');

    if (window.lucide) window.lucide.createIcons();
  }

  return {
    getReports,
    getOutbox,
    addReport,
    renderReportList,
    setNetworkMode,
    syncOfflineQueue,
    scanSamplePhoto,
    SAMPLE_PHOTOS,
    getNetworkMode: () => networkMode
  };
})();

window.CrowdsourceManager = CrowdsourceManager;
