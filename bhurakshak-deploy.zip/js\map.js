/**
 * BhuRakshak GIS Command Map Engine (Leaflet)
 * Smart India Hackathon 2026 - Problem Statement 26001
 * Team: Codebreakers | Organization: Ministry of Development of North Eastern Region (MDoNER) & NDMA
 * 
 * Manages multi-layer geospatial visualization across Northeast India:
 * - Real-time LoRaWAN sensor nodes & landslide hotspots
 * - Critical lifeline highway corridors (NH-10, NH-29, NH-6, NH-13)
 * - Safe relief shelters & evacuation centers
 * - Dynamic crowdsourced citizen reports
 * - State-level fly-to navigation filters
 * - Highway blockage detour routing engine
 * - 100% offline-ready embedded fallbacks (zero CORS failure risk)
 */

const MapEngine = (function () {
  let map = null;
  let hotspotLayer = null;
  let highwayLayer = null;
  let detourLayer = null;
  let shelterLayer = null;
  let crowdsourceLayer = null;
  let heatmapLayer = null;

  let baseMaps = {};
  let hotspotsData = [];
  let highwaysData = null;
  let activeStateFilter = 'all';

  // Authoritative Embedded NER Datasets (Guaranteed zero-failure on file:/// and offline)
  const DEFAULT_HOTSPOTS = [
    {
      id: "NER-EKH-01",
      name: "Cherrapunji - Sohra Escarpment",
      state: "Meghalaya",
      district: "East Khasi Hills",
      lat: 25.2986,
      lng: 91.7324,
      elevation: 1430,
      slopeAngle: 42.5,
      lithology: "Sandstone & Shale with Coal Seams",
      soilType: "Laterite Loam (High saturation potential)",
      baseRiskScore: 0.82,
      riskLevel: "CRITICAL",
      activeSensors: 4,
      vulnerablePopulation: 14200,
      criticalRoad: "SH-5 Cherra-Shella Highway",
      sensorId: "SN-SOHRA-01",
      rainfallMm24h: 94.5,
      soilMoisturePct: 88.2,
      tiltDegrees: 4.8,
      porePressureKPa: 42.1
    },
    {
      id: "NER-SKM-02",
      name: "Sevoke - Rangpo Corridor (Teesta Gorge)",
      state: "Sikkim",
      district: "East Sikkim / Kalimpong border",
      lat: 27.1767,
      lng: 88.5284,
      elevation: 860,
      slopeAngle: 48.0,
      lithology: "Schists and Phyllite (Highly Fractured)",
      soilType: "Coarse Silty Sand",
      baseRiskScore: 0.89,
      riskLevel: "CRITICAL",
      activeSensors: 6,
      vulnerablePopulation: 28500,
      criticalRoad: "NH-10 (Lifeline to Gangtok)",
      sensorId: "SN-NH10-04",
      rainfallMm24h: 112.0,
      soilMoisturePct: 92.4,
      tiltDegrees: 5.9,
      porePressureKPa: 54.0
    },
    {
      id: "NER-NAG-03",
      name: "Phesama - Kohima Pass",
      state: "Nagaland",
      district: "Kohima",
      lat: 25.6421,
      lng: 94.1135,
      elevation: 1444,
      slopeAngle: 38.2,
      lithology: "Disang Shales (Prone to slumping)",
      soilType: "Clayey Silt",
      baseRiskScore: 0.74,
      riskLevel: "WARNING",
      activeSensors: 3,
      vulnerablePopulation: 19000,
      criticalRoad: "NH-29 (Dimapur - Kohima - Imphal Highway)",
      sensorId: "SN-KOH-02",
      rainfallMm24h: 68.0,
      soilMoisturePct: 76.5,
      tiltDegrees: 3.1,
      porePressureKPa: 31.8
    },
    {
      id: "NER-MIZ-04",
      name: "Ramhlun - Aizawl Slopes",
      state: "Mizoram",
      district: "Aizawl",
      lat: 23.7271,
      lng: 92.7176,
      elevation: 1132,
      slopeAngle: 39.8,
      lithology: "Bhuban Sandstone & Siltstone",
      soilType: "Red Lateritic Clay",
      baseRiskScore: 0.69,
      riskLevel: "WARNING",
      activeSensors: 4,
      vulnerablePopulation: 32000,
      criticalRoad: "NH-54 / Aizawl Bypass",
      sensorId: "SN-AZL-03",
      rainfallMm24h: 62.0,
      soilMoisturePct: 72.1,
      tiltDegrees: 2.7,
      porePressureKPa: 28.5
    },
    {
      id: "NER-ASM-05",
      name: "Haflong - Jatinga Ridge",
      state: "Assam",
      district: "Dima Hasao",
      lat: 25.1764,
      lng: 93.0232,
      elevation: 680,
      slopeAngle: 34.6,
      lithology: "Barail Sandstones & Conglomerates",
      soilType: "Sandy Clay Loam",
      baseRiskScore: 0.63,
      riskLevel: "WATCH",
      activeSensors: 3,
      vulnerablePopulation: 11500,
      criticalRoad: "NH-27 East-West Corridor (Lumding-Silchar)",
      sensorId: "SN-HFL-01",
      rainfallMm24h: 45.0,
      soilMoisturePct: 65.0,
      tiltDegrees: 1.9,
      porePressureKPa: 22.4
    },
    {
      id: "NER-ARU-06",
      name: "Bhalukpong - Tenga Valley",
      state: "Arunachal Pradesh",
      district: "West Kameng",
      lat: 27.0142,
      lng: 92.6418,
      elevation: 1280,
      slopeAngle: 45.2,
      lithology: "Gneiss and Granitoids (High fracturing)",
      soilType: "Gravelly Sandy Loam",
      baseRiskScore: 0.77,
      riskLevel: "WARNING",
      activeSensors: 5,
      vulnerablePopulation: 8400,
      criticalRoad: "NH-13 (Balipara-Charduar-Tawang Axis)",
      sensorId: "SN-BHK-05",
      rainfallMm24h: 78.0,
      soilMoisturePct: 79.4,
      tiltDegrees: 3.6,
      porePressureKPa: 36.2
    },
    {
      id: "NER-MEG-07",
      name: "Umiam - Mawlyndep Cut Slopes",
      state: "Meghalaya",
      district: "Ri-Bhoi",
      lat: 25.6698,
      lng: 91.9056,
      elevation: 1020,
      slopeAngle: 36.0,
      lithology: "Shillong Group Quartzites",
      soilType: "Red Sandy Loam",
      baseRiskScore: 0.48,
      riskLevel: "WATCH",
      activeSensors: 2,
      vulnerablePopulation: 7200,
      criticalRoad: "NH-6 (Guwahati - Shillong Highway)",
      sensorId: "SN-UMI-02",
      rainfallMm24h: 38.0,
      soilMoisturePct: 58.0,
      tiltDegrees: 1.2,
      porePressureKPa: 17.5
    },
    {
      id: "NER-MAN-08",
      name: "Tupul - Noney Railway Slopes",
      state: "Manipur",
      district: "Noney",
      lat: 24.8167,
      lng: 93.6833,
      elevation: 720,
      slopeAngle: 44.0,
      lithology: "Disang Shale and Mudstones",
      soilType: "Fine Clay (Expansive and fragile)",
      baseRiskScore: 0.85,
      riskLevel: "CRITICAL",
      activeSensors: 4,
      vulnerablePopulation: 6100,
      criticalRoad: "NH-37 (Imphal - Jiribam Highway)",
      sensorId: "SN-TUP-01",
      rainfallMm24h: 98.0,
      soilMoisturePct: 89.5,
      tiltDegrees: 5.1,
      porePressureKPa: 49.3
    },
    {
      id: "NER-TRP-09",
      name: "Jampui Hills Escarpment",
      state: "Tripura",
      district: "North Tripura",
      lat: 23.9167,
      lng: 92.2667,
      elevation: 930,
      slopeAngle: 33.5,
      lithology: "Surma Sandstone & Siltstone",
      soilType: "Sandy Loam",
      baseRiskScore: 0.42,
      riskLevel: "NORMAL",
      activeSensors: 2,
      vulnerablePopulation: 5800,
      criticalRoad: "State Highway 1 (Kanchanpur Axis)",
      sensorId: "SN-JMP-01",
      rainfallMm24h: 28.0,
      soilMoisturePct: 48.5,
      tiltDegrees: 0.8,
      porePressureKPa: 14.2
    }
  ];

  const DEFAULT_SHELTERS = [
    {
      id: "SH-01",
      name: "Sohra Community Hall Relief Center",
      state: "Meghalaya",
      lat: 25.305,
      lng: 91.715,
      capacity: 850,
      supplies: "Adequate (Medical + Ration)"
    },
    {
      id: "SH-02",
      name: "Rangpo ITBP Disaster Relief Station",
      state: "Sikkim",
      lat: 27.185,
      lng: 88.515,
      capacity: 1200,
      supplies: "High (SDRF Base Camp)"
    },
    {
      id: "SH-03",
      name: "Kohima Multi-Utility Stadium Safe Zone",
      state: "Nagaland",
      lat: 25.685,
      lng: 94.102,
      capacity: 2500,
      supplies: "Fully Equipped"
    },
    {
      id: "SH-04",
      name: "Aizawl Sports Complex Relief Camp",
      state: "Mizoram",
      lat: 23.742,
      lng: 92.731,
      capacity: 1800,
      supplies: "Adequate"
    },
    {
      id: "SH-05",
      name: "Haflong District Indoor Stadium Relief Camp",
      state: "Assam",
      lat: 25.185,
      lng: 93.015,
      capacity: 1400,
      supplies: "Adequate (NDRF Mobile Hospital)"
    }
  ];

  const DEFAULT_HIGHWAYS = {
    type: "FeatureCollection",
    features: [
      {
        type: "Feature",
        properties: {
          id: "NH-10",
          name: "NH-10 (Sevoke - Teesta - Rangpo - Gangtok)",
          status: "CRITICAL RISK",
          color: "#ef4444",
          vulnerability: "Extreme (Teesta River Gorge slope failures)",
          lengthKm: 115,
          dailyTraffic: "8,500 vehicles (Essential supply lifeline)",
          blockageKm: "Km 38 Teesta Bazaar",
          detourText: "Divert via NH-717A (Bagrakote - Labha - Reshi - Rangpo)"
        },
        geometry: {
          type: "LineString",
          coordinates: [
            [88.4722, 26.8833],
            [88.4891, 26.9612],
            [88.4985, 27.0543],
            [88.5284, 27.1767],
            [88.5421, 27.2450],
            [88.6138, 27.3314]
          ]
        }
      },
      {
        type: "Feature",
        properties: {
          id: "NH-29",
          name: "NH-29 (Dimapur - Chumukedima - Phesama - Kohima)",
          status: "HIGH ALERT",
          color: "#f97316",
          vulnerability: "High (Disang shales subsidence, Paglapahar rockfalls)",
          lengthKm: 74,
          dailyTraffic: "12,000 vehicles (Nagaland & Manipur Lifeline)",
          blockageKm: "Km 18 Paglapahar",
          detourText: "Divert light vehicles via Niuland - Kohima bypass"
        },
        geometry: {
          type: "LineString",
          coordinates: [
            [93.7267, 25.9068],
            [93.8124, 25.8241],
            [93.9450, 25.7532],
            [94.0531, 25.6841],
            [94.1135, 25.6421],
            [94.1200, 25.6701]
          ]
        }
      },
      {
        type: "Feature",
        properties: {
          id: "NH-6",
          name: "NH-6 (Guwahati - Shillong - Jowai - Silchar)",
          status: "MODERATE MONITORING",
          color: "#eab308",
          vulnerability: "Moderate (Hill cutting slips near Sonapur tunnel)",
          lengthKm: 310,
          dailyTraffic: "16,500 vehicles (Assam - Meghalaya - Barak Valley)",
          blockageKm: "Sonapur Tunnel Approach",
          detourText: "Single-lane alternate pilot convoy active"
        },
        geometry: {
          type: "LineString",
          coordinates: [
            [91.7314, 26.1584],
            [91.8210, 25.9210],
            [91.9056, 25.6698],
            [91.8833, 25.5788],
            [92.2045, 25.4412],
            [92.4821, 25.1102],
            [92.7989, 24.8333]
          ]
        }
      },
      {
        type: "Feature",
        properties: {
          id: "NH-13",
          name: "NH-13 (Bhalukpong - Tenga - Dirang - Sela - Tawang)",
          status: "WATCH",
          color: "#f97316",
          vulnerability: "High (High-altitude seismic & glacial debris flows)",
          lengthKm: 240,
          dailyTraffic: "4,200 vehicles (Strategic Border Highway)",
          blockageKm: "Sela Tunnel West Portal",
          detourText: "Convoy controlled movement"
        },
        geometry: {
          type: "LineString",
          coordinates: [
            [92.6418, 27.0142],
            [92.4812, 27.2104],
            [92.2351, 27.3582],
            [92.1021, 27.5021],
            [91.8687, 27.5861]
          ]
        }
      }
    ]
  };

  // Detour geometries for blocked highways
  const DETOUR_ROUTES = [
    {
      id: "DETOUR-NH10",
      name: "NH-717A Alternate Lifeline Corridor (Safe Bypass)",
      forHighway: "NH-10",
      color: "#38bdf8",
      description: "Bagrakote - Labha - Algarah - Reshi - Rhenock - Rangpo (+1h 40m travel time, BRO cleared)",
      coords: [
        [26.8833, 88.4722],
        [26.9800, 88.6200],
        [27.0850, 88.6500],
        [27.1400, 88.6100],
        [27.1767, 88.5284]
      ]
    },
    {
      id: "DETOUR-NH29",
      name: "Niuland Rural Hill Bypass (Light Vehicles Only)",
      forHighway: "NH-29",
      color: "#38bdf8",
      description: "Dimapur - Niuland - Chumukedima Hill Ridge - Kohima Bypass (+2h 15m, Convoy escort)",
      coords: [
        [25.9068, 93.7267],
        [25.8600, 93.8900],
        [25.7200, 94.0100],
        [25.6701, 94.1200]
      ]
    }
  ];

  // State bounding center points & zoom levels
  const STATE_VIEWPORTS = {
    all: { center: [26.1584, 91.7314], zoom: 7 },
    meghalaya: { center: [25.5788, 91.8933], zoom: 9 },
    sikkim: { center: [27.3314, 88.6138], zoom: 9 },
    nagaland: { center: [25.6701, 94.1200], zoom: 9 },
    assam: { center: [25.5000, 92.8000], zoom: 8 },
    manipur: { center: [24.8170, 93.9368], zoom: 9 },
    arunachal: { center: [27.2000, 92.8000], zoom: 8 },
    mizoram: { center: [23.7271, 92.7176], zoom: 9 },
    tripura: { center: [23.8315, 91.2868], zoom: 9 }
  };

  // Initialize Map
  function initMap(containerId = 'gis-map') {
    if (map) {
      setTimeout(() => { if (map) map.invalidateSize(); }, 50);
      return map;
    }

    const container = document.getElementById(containerId);
    if (!container) {
      console.warn(`Map container #${containerId} not found in DOM.`);
      return null;
    }

    if (typeof L === 'undefined') {
      console.warn("Leaflet library not ready yet, retrying initMap in 250ms...");
      setTimeout(() => initMap(containerId), 250);
      return null;
    }

    try {
      if (L.Icon && L.Icon.Default) {
        L.Icon.Default.imagePath = 'vendor/leaflet/images/';
      }

      map = L.map(containerId, {
        center: [26.1584, 91.7314],
        zoom: 7,
        zoomControl: false,
        preferCanvas: true
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      // Basemap 1: Dark Command (Tactical CartoDB)
      const darkTiles = L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png', {
        attribution: '&copy; CartoDB &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        subdomains: 'abcd',
        maxZoom: 19
      });

      // Basemap 2: Universal OpenStreetMap (Guaranteed global reliability)
      const osmTiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
      });

      // Basemap 3: Satellite Imagery (Esri World Imagery / ISRO Bhuvan)
      const satelliteTiles = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri, USDA, USGS, ISRO Bhuvan',
        maxZoom: 18
      });

      // Basemap 4: Topographic Elevation (OpenTopoMap)
      const topoTiles = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        attribution: 'Map data: &copy; OpenStreetMap, SRTM | OpenTopoMap',
        maxZoom: 17
      });

      // Add default dark tiles (with OSM fallback on error)
      darkTiles.addTo(map);

      baseMaps = {
        "Dark Command": darkTiles,
        "OpenStreetMap": osmTiles,
        "Satellite": satelliteTiles,
        "Topographic": topoTiles
      };

      // Layer groups
      hotspotLayer = L.layerGroup().addTo(map);
      highwayLayer = L.layerGroup().addTo(map);
      detourLayer = L.layerGroup().addTo(map);
      shelterLayer = L.layerGroup().addTo(map);
      crowdsourceLayer = L.layerGroup().addTo(map);
      heatmapLayer = L.layerGroup().addTo(map);

      // Synchronous immediate render with embedded defaults (guaranteed zero CORS error!)
      hotspotsData = DEFAULT_HOTSPOTS;
      highwaysData = DEFAULT_HIGHWAYS;
      renderHotspots(hotspotsData);
      renderHighways(highwaysData);
      renderDetours();
      renderShelters(DEFAULT_SHELTERS);
      renderRiskHeatBuffers(hotspotsData);

      // Try fetching external JSON if running via HTTP server
      loadData();

      // Listen for new field reports
      window.addEventListener('new-field-report', (e) => {
        addCrowdsourcePin(e.detail);
      });

      // Listen for telemetry updates
      window.addEventListener('telemetry-updated', (e) => {
        updateSensorTelemetryOnMap(e.detail);
      });

      // Multiple sizing passes to prevent black container rendering
      [100, 350, 800, 1500].forEach(delay => {
        setTimeout(() => {
          if (map) map.invalidateSize();
        }, delay);
      });

      window.addEventListener('resize', () => {
        if (map) map.invalidateSize();
      });

      console.log("BhuRakshak Leaflet GIS Command Map initialized successfully.");
      return map;
    } catch (err) {
      console.error("Critical error initializing Leaflet map:", err);
      return null;
    }
  }

  function switchBasemap(name) {
    if (!map || !baseMaps[name]) return;
    Object.values(baseMaps).forEach(layer => map.removeLayer(layer));
    baseMaps[name].addTo(map);
  }

  function loadData() {
    // Attempt HTTP fetch (if running locally or hosted)
    fetch('assets/data/ner_hotspots.json')
      .then(res => res.json())
      .then(data => {
        if (data && data.hotspots && data.hotspots.length) {
          hotspotsData = data.hotspots;
          renderHotspots(hotspotsData);
          if (data.safeShelters) renderShelters(data.safeShelters);
          renderRiskHeatBuffers(hotspotsData);
        }
      })
      .catch(() => {
        // Silently use the already loaded DEFAULT_HOTSPOTS
      });

    fetch('assets/data/highways.json')
      .then(res => res.json())
      .then(geo => {
        if (geo && geo.features) {
          highwaysData = geo;
          renderHighways(geo);
        }
      })
      .catch(() => {
        // Silently use the already loaded DEFAULT_HIGHWAYS
      });

    // Load initial crowdsourced reports
    if (window.CrowdsourceManager) {
      const reports = window.CrowdsourceManager.getReports();
      reports.forEach(r => addCrowdsourcePin(r));
    }
  }

  function renderHotspots(hotspots) {
    if (!hotspotLayer) return;
    hotspotLayer.clearLayers();

    hotspots.forEach(h => {
      // Filter check
      if (activeStateFilter !== 'all') {
        const hState = (h.state || '').toLowerCase();
        if (!hState.includes(activeStateFilter.toLowerCase())) return;
      }

      const isCrit = h.riskLevel === 'CRITICAL';
      const isWarn = h.riskLevel === 'WARNING';
      const isWatch = h.riskLevel === 'WATCH';
      
      const pinClass = isCrit ? 'pin-critical pulse-critical' : (isWarn ? 'pin-warning pulse-warning' : (isWatch ? 'pin-watch' : 'pin-normal'));
      const badgeClass = isCrit ? 'badge-critical' : (isWarn ? 'badge-warning' : 'badge-watch');

      const customIcon = L.divIcon({
        className: 'custom-sensor-icon',
        html: `<div class="sensor-pin ${pinClass}" id="pin-${h.id}" title="${h.name}">${Math.round(h.baseRiskScore * 100)}%</div>`,
        iconSize: [26, 26],
        iconAnchor: [13, 13]
      });

      const marker = L.marker([h.lat, h.lng], { icon: customIcon });

      const popupContent = `
        <div class="p-2.5 text-xs font-sans min-w-[250px]">
          <div class="flex items-center justify-between border-b border-slate-700 pb-1.5 mb-2">
            <span class="font-mono text-cyan-400 font-bold">${h.id}</span>
            <span class="${badgeClass} px-2 py-0.5 rounded text-[10px] font-bold">${h.riskLevel}</span>
          </div>
          <div class="font-bold text-sm text-white">${h.name}</div>
          <div class="text-slate-400 text-[11px] mb-2">${h.district}, ${h.state} • Elev: ${h.elevation}m</div>
          
          <div class="grid grid-cols-2 gap-1.5 bg-slate-900/90 p-2 rounded border border-slate-800 mb-2">
            <div><span class="text-slate-400">Rainfall:</span> <strong class="text-sky-400">${h.rainfallMm24h} mm/h</strong></div>
            <div><span class="text-slate-400">Soil Sat:</span> <strong class="text-emerald-400">${h.soilMoisturePct}%</strong></div>
            <div><span class="text-slate-400">Slope:</span> <strong class="text-amber-400">${h.slopeAngle}°</strong></div>
            <div><span class="text-slate-400">Tilt:</span> <strong class="text-rose-400">${h.tiltDegrees}°</strong></div>
          </div>

          <div class="text-[11px] text-slate-300 space-y-1 mb-3">
            <div><span class="text-slate-500">Lithology:</span> ${h.lithology}</div>
            <div><span class="text-slate-500">Lifeline:</span> <strong class="text-cyan-300">${h.criticalRoad}</strong></div>
            <div><span class="text-slate-500">Pop. at Risk:</span> <strong>${h.vulnerablePopulation.toLocaleString()} citizens</strong></div>
          </div>

          <button onclick="MapEngine.selectHotspotForAnalysis('${h.id}')" class="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-medium py-1 px-2 rounded text-center transition flex items-center justify-center">
            Focus Real-Time Telemetry & Geotechnical Analysis
          </button>
        </div>
      `;

      marker.bindPopup(popupContent);
      hotspotLayer.addLayer(marker);
    });
  }

  function renderRiskHeatBuffers(hotspots) {
    if (!heatmapLayer) return;
    heatmapLayer.clearLayers();

    hotspots.forEach(h => {
      let color = '#10b981';
      let radius = 12000;
      if (h.riskLevel === 'CRITICAL') {
        color = '#ef4444';
        radius = 24000;
      } else if (h.riskLevel === 'WARNING') {
        color = '#f97316';
        radius = 18000;
      } else if (h.riskLevel === 'WATCH') {
        color = '#eab308';
        radius = 14000;
      }

      const circle = L.circle([h.lat, h.lng], {
        radius: radius,
        color: color,
        weight: 1,
        fillColor: color,
        fillOpacity: 0.16
      });
      heatmapLayer.addLayer(circle);
    });
  }

  function renderHighways(geo) {
    if (!highwayLayer || !geo) return;
    highwayLayer.clearLayers();

    L.geoJSON(geo, {
      style: function (feature) {
        const isCrit = feature.properties.status === 'CRITICAL RISK';
        return {
          color: feature.properties.color || '#38bdf8',
          weight: isCrit ? 5 : 4,
          opacity: 0.9,
          dashArray: isCrit ? '8, 6' : null
        };
      },
      onEachFeature: function (feature, layer) {
        const props = feature.properties;
        layer.bindTooltip(`
          <div class="text-xs p-1.5 font-sans">
            <strong>${props.name}</strong><br/>
            Status: <span class="font-bold" style="color:${props.color}">${props.status}</span><br/>
            Blockage: <span class="text-rose-400 font-semibold">${props.blockageKm || 'Monitored'}</span><br/>
            Traffic: ${props.dailyTraffic}
          </div>
        `, { sticky: true });

        layer.bindPopup(`
          <div class="p-2 text-xs font-sans min-w-[220px]">
            <div class="font-bold text-sm text-white border-b border-slate-700 pb-1 mb-1.5">${props.name}</div>
            <div class="mb-1 text-slate-300">Status: <strong style="color:${props.color}">${props.status}</strong></div>
            <div class="mb-1 text-slate-400">Vulnerability: ${props.vulnerability}</div>
            <div class="p-2 bg-slate-900 rounded border border-slate-800 text-cyan-300 mt-2">
              <strong>Detour Route:</strong><br/>${props.detourText || 'No detour required'}
            </div>
            <button onclick="MapEngine.focusHighway('${props.id}')" class="mt-2 w-full bg-slate-800 hover:bg-slate-700 text-slate-200 py-1 px-2 rounded text-center">
              Highlight Corridor & Detour
            </button>
          </div>
        `);
      }
    }).addTo(highwayLayer);
  }

  function renderDetours() {
    if (!detourLayer) return;
    detourLayer.clearLayers();

    DETOUR_ROUTES.forEach(detour => {
      const line = L.polyline(detour.coords, {
        color: detour.color,
        weight: 3.5,
        opacity: 0.85,
        dashArray: '4, 8'
      });

      line.bindTooltip(`
        <div class="text-xs p-1 font-sans">
          <strong class="text-cyan-400">⚡ AI Recommended Detour</strong><br/>
          ${detour.name}<br/>
          <span class="text-slate-300">${detour.description}</span>
        </div>
      `, { sticky: true });

      detourLayer.addLayer(line);
    });
  }

  function renderShelters(shelters) {
    if (!shelterLayer) return;
    shelterLayer.clearLayers();

    shelters.forEach(s => {
      const icon = L.divIcon({
        className: 'shelter-icon',
        html: `<div class="bg-emerald-600 text-white rounded-md p-1 shadow-lg border border-white text-[10px] font-bold flex items-center justify-center" style="width:22px;height:22px;">⛺</div>`,
        iconSize: [22, 22]
      });

      const marker = L.marker([s.lat, s.lng], { icon: icon });
      marker.bindPopup(`
        <div class="text-xs p-2 min-w-[200px]">
          <span class="badge-normal px-2 py-0.5 rounded text-[10px] font-bold">SAFE EVACUATION SHELTER</span>
          <div class="font-bold text-emerald-400 text-sm mt-1">${s.name}</div>
          <div class="text-slate-300 mt-1">State: <strong>${s.state}</strong></div>
          <div class="text-slate-300">Capacity: <strong class="text-white">${s.capacity} persons</strong></div>
          <div class="text-slate-300">Supplies: <strong class="text-sky-300">${s.supplies}</strong></div>
        </div>
      `);
      shelterLayer.addLayer(marker);
    });
  }

  function addCrowdsourcePin(report) {
    if (!crowdsourceLayer) return;
    const isCrit = report.severity === 'CRITICAL';
    const icon = L.divIcon({
      className: 'crowdsource-pin',
      html: `<div class="bg-purple-600 text-white rounded-full p-1 border-2 border-white shadow-lg text-[10px] flex items-center justify-center animate-bounce" style="width:24px;height:24px;">📍</div>`,
      iconSize: [24, 24]
    });

    const marker = L.marker([report.lat, report.lng], { icon: icon });
    marker.bindPopup(`
      <div class="text-xs p-2 min-w-[210px]">
        <span class="bg-purple-900 text-purple-200 px-1.5 py-0.5 rounded text-[10px] font-mono">CROWD REPORT</span>
        <div class="font-bold text-sm text-white mt-1">${report.type}</div>
        <div class="text-slate-400">${report.location}</div>
        <div class="mt-1 text-slate-300">Crack Width: <strong>${report.crackWidth}</strong></div>
        <div class="text-slate-300">Impact: <strong>${report.roadImpact}</strong></div>
        <div class="text-emerald-400 font-semibold mt-1">Status: ${report.status}</div>
      </div>
    `);
    crowdsourceLayer.addLayer(marker);
  }

  function updateSensorTelemetryOnMap(telemetry) {
    const primary = hotspotsData.find(h => h.id === "NER-EKH-01");
    if (primary) {
      primary.rainfallMm24h = telemetry.rainfall;
      primary.soilMoisturePct = telemetry.moisture;
      primary.tiltDegrees = telemetry.tilt;
      primary.porePressureKPa = telemetry.porePressure;
    }
  }

  function selectHotspotForAnalysis(hotspotId) {
    const spot = hotspotsData.find(h => h.id === hotspotId);
    if (!spot) return;

    if (map) {
      map.flyTo([spot.lat, spot.lng], 10, { duration: 1.2 });
    }

    const sliderRain = document.getElementById('sim-rainfall');
    const sliderMoist = document.getElementById('sim-moisture');
    const sliderSlope = document.getElementById('sim-slope');
    const sliderTilt = document.getElementById('sim-tilt');

    if (sliderRain) sliderRain.value = spot.rainfallMm24h;
    if (sliderMoist) sliderMoist.value = spot.soilMoisturePct;
    if (sliderSlope) sliderSlope.value = spot.slopeAngle;
    if (sliderTilt) sliderTilt.value = spot.tiltDegrees;

    if (window.App) {
      window.App.updateSimulation();
      window.App.setActiveTab('tab-simulator');
    }
  }

  function filterByState(stateCode) {
    activeStateFilter = stateCode.toLowerCase();
    
    // Fly map camera to target state
    const targetView = STATE_VIEWPORTS[activeStateFilter] || STATE_VIEWPORTS.all;
    if (map) {
      map.flyTo(targetView.center, targetView.zoom, { duration: 1.0 });
    }

    // Re-render markers with active state filter
    renderHotspots(hotspotsData);
  }

  function focusHighway(highwayId) {
    const highway = (highwaysData.features || []).find(f => f.properties.id === highwayId);
    if (!highway || !map) return;

    const coords = highway.geometry.coordinates;
    const midIndex = Math.floor(coords.length / 2);
    const midPoint = coords[midIndex];

    map.flyTo([midPoint[1], midPoint[0]], 10, { duration: 1.0 });

    if (window.App) {
      window.App.showNotificationToast(`Corridor ${highwayId} selected: ${highway.properties.detourText}`);
    }
  }

  function triggerCloudburstOnMap() {
    // Elevated readings for Cherrapunji and Teesta Gorge
    const cherra = hotspotsData.find(h => h.id === "NER-EKH-01");
    if (cherra) {
      cherra.riskLevel = "CRITICAL";
      cherra.baseRiskScore = 0.94;
      cherra.rainfallMm24h = 135.0;
      cherra.soilMoisturePct = 96.0;
      cherra.tiltDegrees = 6.4;
    }

    const teesta = hotspotsData.find(h => h.id === "NER-SKM-02");
    if (teesta) {
      teesta.riskLevel = "CRITICAL";
      teesta.baseRiskScore = 0.96;
      teesta.rainfallMm24h = 142.0;
      teesta.soilMoisturePct = 98.0;
      teesta.tiltDegrees = 7.1;
    }

    renderHotspots(hotspotsData);
    renderRiskHeatBuffers(hotspotsData);

    if (map) {
      map.flyTo([25.2986, 91.7324], 9, { duration: 1.2 });
    }
  }

  function toggleLayer(layerName, enabled) {
    if (!map) return;
    const layerMap = {
      sensors: hotspotLayer,
      highways: highwayLayer,
      detours: detourLayer,
      shelters: shelterLayer,
      crowdsource: crowdsourceLayer,
      heatmap: heatmapLayer
    };

    const target = layerMap[layerName];
    if (!target) return;

    if (enabled && !map.hasLayer(target)) {
      map.addLayer(target);
    } else if (!enabled && map.hasLayer(target)) {
      map.removeLayer(target);
    }
  }

  return {
    initMap,
    switchBasemap,
    toggleLayer,
    selectHotspotForAnalysis,
    selectHotspotForDemo: selectHotspotForAnalysis,
    filterByState,
    focusHighway,
    triggerCloudburstOnMap,
    getHotspots: () => hotspotsData,
    getActiveStateFilter: () => activeStateFilter
  };
})();

window.MapEngine = MapEngine;
