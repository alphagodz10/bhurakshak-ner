/**
 * BhuRakshak Main Application Coordinator
 * Smart India Hackathon 2026 - Problem Statement 26001
 * Team: Codebreakers | Organization: MDoNER & NDMA
 */

const App = (function () {
  let activeTab = 'tab-map';
  let demoTimer = null;

  function init() {
    // 1. Initialize Map
    window.MapEngine.initMap();

    // 2. Initialize Telemetry Charts
    window.TelemetryManager.initCharts();

    // 3. Render initial crowdsource reports
    window.CrowdsourceManager.renderReportList();

    // 4. Bind UI Event Listeners
    bindUIEvents();

    // 5. Run initial AI Simulation calculation
    updateSimulation();

    // 6. Initialize Lucide Icons
    if (window.lucide) {
      window.lucide.createIcons();
    }

    console.log("BhuRakshak Disaster Command Center initialized successfully.");
  }

  function bindUIEvents() {
    // Tab Switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetTab = btn.getAttribute('data-tab');
        setActiveTab(targetTab);
      });
    });

    // Basemap Switcher
    const basemapSelect = document.getElementById('basemap-select');
    if (basemapSelect) {
      basemapSelect.addEventListener('change', (e) => {
        window.MapEngine.switchBasemap(e.target.value);
      });
    }

    // Layer Toggles
    ['sensors', 'highways', 'detours', 'shelters', 'crowdsource', 'heatmap'].forEach(layer => {
      const toggle = document.getElementById(`toggle-${layer}`);
      if (toggle) {
        toggle.addEventListener('change', (e) => {
          window.MapEngine.toggleLayer(layer, e.target.checked);
        });
      }
    });

    // State Filter Pills
    document.querySelectorAll('.state-filter-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.state-filter-pill').forEach(b => {
          b.classList.remove('bg-cyan-600', 'text-white', 'border-cyan-400');
          b.classList.add('bg-slate-900/80', 'text-slate-300', 'border-slate-800');
        });
        btn.classList.remove('bg-slate-900/80', 'text-slate-300', 'border-slate-800');
        btn.classList.add('bg-cyan-600', 'text-white', 'border-cyan-400');
        
        const stateCode = btn.getAttribute('data-state');
        window.MapEngine.filterByState(stateCode);
      });
    });

    // Network Connectivity Mode Selector
    const netSelect = document.getElementById('network-mode-select');
    if (netSelect) {
      netSelect.addEventListener('change', (e) => {
        window.CrowdsourceManager.setNetworkMode(e.target.value);
      });
    }

    // Simulator Sliders
    ['sim-rainfall', 'sim-moisture', 'sim-slope', 'sim-tilt'].forEach(id => {
      const slider = document.getElementById(id);
      if (slider) {
        slider.addEventListener('input', () => {
          updateSimulation();
        });
      }
    });

    // Language Selector
    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('bg-cyan-600', 'text-white'));
        btn.classList.add('bg-cyan-600', 'text-white');
        const lang = btn.getAttribute('data-lang');
        window.AlertSystem.setLanguage(lang);
        updateAlertPreview();
      });
    });

    // Emergency Siren Toggle
    const sirenBtn = document.getElementById('btn-toggle-siren');
    if (sirenBtn) {
      sirenBtn.addEventListener('click', () => {
        window.AlertSystem.toggleEmergencySiren();
      });
    }

    // IVR Speech Broadcast
    const ivrBtn = document.getElementById('btn-broadcast-ivr');
    if (ivrBtn) {
      ivrBtn.addEventListener('click', () => {
        window.AlertSystem.broadcastVoiceAlert();
      });
    }

    // Simulated SMS Send
    const smsBtn = document.getElementById('btn-send-sms');
    if (smsBtn) {
      smsBtn.addEventListener('click', () => {
        const phoneInput = document.getElementById('sms-phone-input');
        const phone = phoneInput ? phoneInput.value : "+91 98620 XXXXX";
        showNotificationToast(`SMS dispatched via CAP Gateway to ${phone}!`);
      });
    }

    // Crowdsource Form Submission
    const reportForm = document.getElementById('crowdsource-form');
    if (reportForm) {
      reportForm.addEventListener('submit', (e) => {
        e.preventDefault();
        submitFieldReport();
      });
    }

    // Telemetry Pause/Resume
    const pauseBtn = document.getElementById('btn-toggle-stream');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', () => {
        const isLive = window.TelemetryManager.toggleSimulation();
        pauseBtn.innerHTML = isLive 
          ? '<i data-lucide="pause" class="w-3.5 h-3.5 mr-1 inline"></i> Pause Stream'
          : '<i data-lucide="play" class="w-3.5 h-3.5 mr-1 inline"></i> Resume Stream';
        if (window.lucide) window.lucide.createIcons();
      });
    }

    // Sample Photo Clickers
    document.querySelectorAll('.btn-sample-photo').forEach(btn => {
      btn.addEventListener('click', () => {
        const sampleKey = btn.getAttribute('data-sample');
        window.CrowdsourceManager.scanSamplePhoto(sampleKey);
      });
    });

    // Photo File Input Upload
    const photoFileInput = document.getElementById('rpt-photo-file');
    if (photoFileInput) {
      photoFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function (evt) {
            const previewImg = document.getElementById('report-photo-preview');
            const previewBox = document.getElementById('photo-preview-container');
            const scanBox = document.getElementById('cv-scan-result');
            const confText = document.getElementById('cv-confidence-text');

            if (previewImg) previewImg.src = evt.target.result;
            if (previewBox) previewBox.classList.remove('hidden');
            if (scanBox) scanBox.classList.remove('hidden');
            if (confText) confText.textContent = "95.2% Transverse Shear Rupture (User Upload)";

            showNotificationToast("Uploaded photo analyzed via Computer Vision model!");
          };
          reader.readAsDataURL(file);
        }
      });
    }
  }

  function setActiveTab(tabId) {
    activeTab = tabId;

    // Update Tab Buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
      if (btn.getAttribute('data-tab') === tabId) {
        btn.classList.add('active');
        btn.classList.remove('text-slate-300');
      } else {
        btn.classList.remove('active');
        btn.classList.add('text-slate-300');
      }
    });

    // Update Tab Panes
    document.querySelectorAll('.tab-content').forEach(pane => {
      if (pane.id === tabId) {
        pane.classList.remove('hidden');
      } else {
        pane.classList.add('hidden');
      }
    });

    // Re-render map tiles if switching to GIS map tab
    if (tabId === 'tab-map') {
      setTimeout(() => {
        const map = window.MapEngine.initMap();
        if (map) map.invalidateSize();
      }, 100);
    }

    if (window.lucide) window.lucide.createIcons();
  }

  function updateSimulation() {
    const rain = parseFloat(document.getElementById('sim-rainfall')?.value || 85);
    const moisture = parseFloat(document.getElementById('sim-moisture')?.value || 82);
    const slope = parseFloat(document.getElementById('sim-slope')?.value || 42);
    const tilt = parseFloat(document.getElementById('sim-tilt')?.value || 3.8);

    // Update slider label values
    const lblRain = document.getElementById('val-rainfall');
    const lblMoist = document.getElementById('val-moisture');
    const lblSlope = document.getElementById('val-slope');
    const lblTilt = document.getElementById('val-tilt');

    if (lblRain) lblRain.textContent = rain + ' mm/h';
    if (lblMoist) lblMoist.textContent = moisture + '%';
    if (lblSlope) lblSlope.textContent = slope + '°';
    if (lblTilt) lblTilt.textContent = tilt + '°';

    // AI Prediction
    const prediction = window.AIEngine.predictRiskScore({
      rainfall24h: rain,
      soilMoisture: moisture,
      slopeAngle: slope,
      tiltAngle: tilt
    });

    // Update UI elements
    const gaugeScore = document.getElementById('ai-risk-score');
    const gaugeBadge = document.getElementById('ai-risk-badge');
    const gaugeFoS = document.getElementById('ai-fos-value');
    const gaugeLead = document.getElementById('ai-lead-time');
    const riskProgressBar = document.getElementById('ai-risk-progress');

    if (gaugeScore) gaugeScore.textContent = prediction.percentage + '%';
    if (gaugeFoS) {
      gaugeFoS.textContent = prediction.factorOfSafety;
      gaugeFoS.className = prediction.factorOfSafety < 1.0 ? 'font-mono font-black text-4xl text-rose-500 mt-1' : 'font-mono font-black text-4xl text-emerald-400 mt-1';
    }
    if (gaugeLead) gaugeLead.textContent = prediction.leadTimeHours + ' Hours';

    if (riskProgressBar) {
      riskProgressBar.style.width = prediction.percentage + '%';
      riskProgressBar.style.backgroundColor = prediction.alertColor;
    }

    if (gaugeBadge) {
      gaugeBadge.textContent = prediction.riskLevel;
      gaugeBadge.className = prediction.riskLevel === 'CRITICAL' ? 'badge-critical px-3 py-1 rounded text-sm font-bold animate-pulse'
        : (prediction.riskLevel === 'WARNING' ? 'badge-warning px-3 py-1 rounded text-sm font-bold'
        : 'badge-watch px-3 py-1 rounded text-sm font-bold');
    }

    // Feature contributions
    const contrib = prediction.featureContributions;
    updateBar('bar-contrib-rain', contrib.rainfall);
    updateBar('bar-contrib-moist', contrib.soilMoisture);
    updateBar('bar-contrib-slope', contrib.slope);
    updateBar('bar-contrib-tilt', contrib.tilt);

    // Update alert banner and preview
    updateAlertPreview(prediction);
  }

  function updateBar(elementId, pct) {
    const bar = document.getElementById(elementId);
    if (bar) bar.style.width = pct + '%';
  }

  function applyPreset(presetName) {
    const sliderRain = document.getElementById('sim-rainfall');
    const sliderMoist = document.getElementById('sim-moisture');
    const sliderSlope = document.getElementById('sim-slope');
    const sliderTilt = document.getElementById('sim-tilt');

    if (presetName === 'dry') {
      if (sliderRain) sliderRain.value = 8;
      if (sliderMoist) sliderMoist.value = 35;
      if (sliderSlope) sliderSlope.value = 30;
      if (sliderTilt) sliderTilt.value = 0.8;
      window.AlertSystem.stopSirenSound();
    } else if (presetName === 'moderate') {
      if (sliderRain) sliderRain.value = 45;
      if (sliderMoist) sliderMoist.value = 65;
      if (sliderSlope) sliderSlope.value = 38;
      if (sliderTilt) sliderTilt.value = 1.9;
    } else if (presetName === 'heavy') {
      if (sliderRain) sliderRain.value = 88;
      if (sliderMoist) sliderMoist.value = 85;
      if (sliderSlope) sliderSlope.value = 44;
      if (sliderTilt) sliderTilt.value = 4.2;
    } else if (presetName === 'cloudburst') {
      if (sliderRain) sliderRain.value = 135;
      if (sliderMoist) sliderMoist.value = 96;
      if (sliderSlope) sliderSlope.value = 48;
      if (sliderTilt) sliderTilt.value = 6.4;
      window.AlertSystem.playSirenSound(8);
    }

    updateSimulation();
  }

  function updateAlertPreview(prediction = null) {
    const level = prediction ? prediction.riskLevel : 'CRITICAL';
    const alertData = window.AlertSystem.generateAlertContent(level);

    const alertTitle = document.getElementById('alert-card-title');
    const alertBody = document.getElementById('alert-card-body');
    const alertLang = document.getElementById('alert-active-lang');
    const vmsHeader = document.getElementById('vms-header');
    const vmsSub = document.getElementById('vms-sub');
    const topMarquee = document.getElementById('top-alert-marquee');

    if (alertTitle) alertTitle.textContent = alertData.title;
    if (alertBody) alertBody.textContent = alertData.text;
    if (alertLang) alertLang.textContent = alertData.language;

    if (vmsHeader) vmsHeader.textContent = alertData.vmsHeader;
    if (vmsSub) vmsSub.textContent = alertData.vmsSub;

    if (topMarquee) {
      topMarquee.textContent = `[${alertData.title}] ${alertData.text}`;
    }
  }

  function submitFieldReport() {
    const reporter = document.getElementById('rpt-name')?.value || "Field Officer";
    const role = document.getElementById('rpt-role')?.value || "Citizen";
    const location = document.getElementById('rpt-location')?.value || "Cherrapunji - Shella Road";
    const type = document.getElementById('rpt-type')?.value || "Tension Crack";
    const severity = document.getElementById('rpt-severity')?.value || "CRITICAL";
    const crackWidth = document.getElementById('rpt-crack')?.value || "28 cm";
    const roadImpact = document.getElementById('rpt-impact')?.value || "Single lane obstructed";

    const previewImg = document.getElementById('report-photo-preview');
    const photoUrl = previewImg ? previewImg.src : "https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?w=500&auto=format&fit=crop&q=60";

    const newReport = window.CrowdsourceManager.addReport({
      reporter,
      role,
      location,
      type,
      severity,
      crackWidth,
      roadImpact,
      photoUrl,
      lat: 25.300 + (Math.random() * 0.05 - 0.025),
      lng: 91.730 + (Math.random() * 0.05 - 0.025)
    });

    window.CrowdsourceManager.renderReportList();
    
    // Clear inputs
    const form = document.getElementById('crowdsource-form');
    if (form) form.reset();
  }

  function openEmergencySOSModal() {
    const modal = document.getElementById('sos-modal');
    if (modal) {
      modal.classList.remove('hidden');
      if (window.lucide) window.lucide.createIcons();
    }
  }

  function closeEmergencySOSModal() {
    const modal = document.getElementById('sos-modal');
    if (modal) modal.classList.add('hidden');
  }

  function copyGPSCoordinates() {
    const gpsEl = document.getElementById('sos-gps-display');
    const text = gpsEl ? gpsEl.textContent.trim() : "Latitude: 25.5788° N, Longitude: 91.8933° E";
    navigator.clipboard.writeText(text).then(() => {
      showNotificationToast("GPS Coordinates copied to clipboard for emergency response dispatch!");
    }).catch(() => {
      showNotificationToast("Coordinates: " + text);
    });
  }

  function detectCurrentLocation() {
    if ('geolocation' in navigator) {
      showNotificationToast("Requesting device GPS coordinates...");
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude.toFixed(4);
          const lng = pos.coords.longitude.toFixed(4);
          const locInput = document.getElementById('rpt-location');
          if (locInput) locInput.value = `Geo-Tagged Location (${lat}° N, ${lng}° E)`;
          const gpsBox = document.getElementById('sos-gps-display');
          if (gpsBox) gpsBox.textContent = `Latitude: ${lat}° N, Longitude: ${lng}° E (Device GPS)`;
          showNotificationToast(`GPS Location detected: ${lat}° N, ${lng}° E`);
        },
        () => {
          showNotificationToast("GPS detection unavailable or permission denied. Using mountain sector coordinates.");
        },
        { timeout: 5000 }
      );
    } else {
      showNotificationToast("Geolocation not supported by this browser.");
    }
  }

  function showNotificationToast(msg) {
    const toast = document.getElementById('app-toast');
    const toastMsg = document.getElementById('toast-message');
    if (toast && toastMsg) {
      toastMsg.textContent = msg;
      toast.classList.remove('opacity-0', 'pointer-events-none');
      toast.classList.add('opacity-100');
      setTimeout(() => {
        toast.classList.remove('opacity-100');
        toast.classList.add('opacity-0', 'pointer-events-none');
      }, 4000);
    }
  }

  return {
    init,
    setActiveTab,
    updateSimulation,
    applyPreset,
    submitFieldReport,
    openEmergencySOSModal,
    closeEmergencySOSModal,
    copyGPSCoordinates,
    detectCurrentLocation,
    showNotificationToast
  };
})();

// Initialize on DOM load
window.addEventListener('DOMContentLoaded', () => {
  App.init();
});

window.App = App;
