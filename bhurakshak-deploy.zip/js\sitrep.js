/**
 * BhuRakshak Official Situation Report (SitRep) Generator
 * Smart India Hackathon 2026 - Problem Statement 26001
 * 
 * Generates an official, print-ready disaster advisory bulletin for 
 * District Magistrates (DM), SDMA, NDRF, and MDoNER Disaster Cell.
 */

const SitRepManager = (function () {
  function generateSitRepHTML() {
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
    const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZoneName: 'short' });
    const reportRef = "SITREP/NER/2026/" + Math.floor(1000 + Math.random() * 9000);

    const latest = window.TelemetryManager ? window.TelemetryManager.getLatestReadings() : { rainfall: 94.5, moisture: 88.2, tilt: 4.8, porePressure: 42.1 };
    const reports = window.CrowdsourceManager ? window.CrowdsourceManager.getReports() : [];

    return `
      <div class="bg-white text-slate-900 p-8 max-w-4xl mx-auto rounded-lg shadow-2xl font-sans border-t-8 border-rose-600">
        <!-- Official Government Header -->
        <div class="flex items-center justify-between border-b-2 border-slate-300 pb-4 mb-6">
          <div>
            <div class="text-xs uppercase tracking-widest font-bold text-slate-500">Government of India • Ministry of Development of North Eastern Region (MDoNER)</div>
            <h1 class="text-2xl font-black text-slate-900 tracking-tight">LANDSLIDE EARLY WARNING SITUATION REPORT (SITREP)</h1>
            <div class="text-xs text-slate-600 mt-1">Issued by: National & State Disaster Management Authority (SDMA) NER Cell</div>
          </div>
          <div class="text-right">
            <span class="inline-block bg-rose-600 text-white font-mono font-bold text-xs px-3 py-1 rounded">PRIORITY: URGENT</span>
            <div class="text-xs font-mono text-slate-500 mt-2 font-bold">${reportRef}</div>
            <div class="text-xs text-slate-600">${dateStr} | ${timeStr}</div>
          </div>
        </div>

        <!-- Executive Summary Banner -->
        <div class="bg-amber-50 border-l-4 border-amber-500 p-4 mb-6 text-sm text-slate-800">
          <strong class="font-bold text-amber-900">EXECUTIVE OPERATIONAL ADVISORY:</strong>
          Continuous torrential precipitation over East Khasi Hills (Cherrapunji axis), Teesta Basin (NH-10), and Phesama Pass (NH-29) has driven geotechnical pore-water pressures beyond the critical factor of safety threshold (FoS < 1.05). High risk of deep-seated slope failures and debris flows within the next <strong>3.5 to 6.0 hours</strong>.
        </div>

        <!-- Telemetry & Sensor Summary -->
        <div class="grid grid-cols-4 gap-4 mb-6">
          <div class="border border-slate-200 p-3 rounded bg-slate-50 text-center">
            <div class="text-xs text-slate-500 font-semibold uppercase">Peak Rain Rate</div>
            <div class="text-xl font-bold text-sky-700">${latest.rainfall.toFixed(1)} mm/h</div>
            <div class="text-[10px] text-slate-500">LoRaWAN Automated Sensor</div>
          </div>
          <div class="border border-slate-200 p-3 rounded bg-slate-50 text-center">
            <div class="text-xs text-slate-500 font-semibold uppercase">Soil Saturation</div>
            <div class="text-xl font-bold text-emerald-700">${latest.moisture.toFixed(1)}%</div>
            <div class="text-[10px] text-slate-500">Pore Pressure: ${latest.porePressure.toFixed(1)} kPa</div>
          </div>
          <div class="border border-slate-200 p-3 rounded bg-slate-50 text-center">
            <div class="text-xs text-slate-500 font-semibold uppercase">Inclinometer Tilt</div>
            <div class="text-xl font-bold text-amber-700">${latest.tilt.toFixed(2)}°</div>
            <div class="text-[10px] text-slate-500">Accelerating Shear Creep</div>
          </div>
          <div class="border border-slate-200 p-3 rounded bg-slate-50 text-center">
            <div class="text-xs text-slate-500 font-semibold uppercase">AI Hazard Index</div>
            <div class="text-xl font-bold text-rose-700">89.4% (CRITICAL)</div>
            <div class="text-[10px] text-slate-500">Lead Time: ~4.2 Hours</div>
          </div>
        </div>

        <!-- Critical Corridors Table -->
        <h2 class="text-base font-bold text-slate-900 mb-2 border-b pb-1">1. CRITICAL INFRASTRUCTURE & LIFELINE HIGHWAY STATUS</h2>
        <table class="w-full text-xs text-left mb-6 border border-slate-200">
          <thead class="bg-slate-100 text-slate-700 font-bold">
            <tr>
              <th class="p-2 border">Highway Corridor</th>
              <th class="p-2 border">Affected Sector</th>
              <th class="p-2 border">Current Risk Level</th>
              <th class="p-2 border">Recommended Traffic Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="p-2 border font-semibold">NH-10 (Sevoke - Gangtok)</td>
              <td class="p-2 border">Teesta Gorge (km 32-48)</td>
              <td class="p-2 border text-rose-600 font-bold">RED (Extreme Failure Risk)</td>
              <td class="p-2 border">Full vehicular closure. Divert via Lavah-Reshi route.</td>
            </tr>
            <tr>
              <td class="p-2 border font-semibold">NH-29 (Dimapur - Kohima)</td>
              <td class="p-2 border">Phesama Slide Zone (km 18)</td>
              <td class="p-2 border text-amber-600 font-bold">ORANGE (Active Creep)</td>
              <td class="p-2 border">Light essential vehicles only with convoy pilot.</td>
            </tr>
            <tr>
              <td class="p-2 border font-semibold">SH-5 (Cherrapunji Escarpment)</td>
              <td class="p-2 border">Sohra - Shella Sector</td>
              <td class="p-2 border text-rose-600 font-bold">RED (Debris Flow Hazard)</td>
              <td class="p-2 border">Evacuate slope-adjacent settlements immediately.</td>
            </tr>
          </tbody>
        </table>

        <!-- Citizen & Field Reports -->
        <h2 class="text-base font-bold text-slate-900 mb-2 border-b pb-1">2. FIELD VALIDATION & CROWDSOURCED VERIFICATIONS</h2>
        <div class="text-xs text-slate-700 mb-6">
          <p class="mb-2">Total verified ground incidents logged: <strong>${reports.length} reports</strong>.</p>
          <ul class="list-disc pl-5 space-y-1">
            ${reports.slice(0, 3).map(r => `
              <li><strong>${r.location}</strong>: ${r.type} (${r.severity}) - Reported by ${r.reporter} (${r.status})</li>
            `).join('')}
          </ul>
        </div>

        <!-- SOP Directive for District Magistrates -->
        <h2 class="text-base font-bold text-slate-900 mb-2 border-b pb-1">3. DISTRICT ADMINISTRATION DIRECTIVES (SOP 4-B)</h2>
        <ol class="list-decimal pl-5 text-xs text-slate-700 space-y-1 mb-6">
          <li><strong>Relief Camps:</strong> Ensure 24-hour power and clean water at designated safe shelters (Capacity for 6,350 persons primed).</li>
          <li><strong>SDRF/NDRF:</strong> Station heavy earthmoving excavators and quick-response rescue squads at Teesta Bazaar and Kohima checkposts.</li>
          <li><strong>Public Alert Broadcast:</strong> Multilingual sirens, CAP SMS, and IVR voice broadcasts to be continued every 30 minutes until rain subsides.</li>
        </ol>

        <!-- Sign-off Footer -->
        <div class="flex justify-between items-end pt-4 border-t-2 border-slate-200 text-xs text-slate-500">
          <div>
            <div>Platform: <strong>BhuRakshak Landslide Early Warning Engine</strong></div>
            <div>Built for SIH 2026 • PS ID: 26001 • Team Codebreakers</div>
          </div>
          <div class="text-right">
            <div class="font-bold text-slate-800">State Disaster Management Authority</div>
            <div>Control Room Officer-in-Charge (Seal & Stamp)</div>
          </div>
        </div>
      </div>
    `;
  }

  function printSitRep() {
    const modalContent = document.getElementById('sitrep-modal-content');
    if (!modalContent) return;
    
    modalContent.innerHTML = generateSitRepHTML();
    
    // Open modal
    const modal = document.getElementById('sitrep-modal');
    if (modal) modal.classList.remove('hidden');
  }

  function closeSitRepModal() {
    const modal = document.getElementById('sitrep-modal');
    if (modal) modal.classList.add('hidden');
  }

  return {
    generateSitRepHTML,
    printSitRep,
    closeSitRepModal
  };
})();

window.SitRepManager = SitRepManager;
