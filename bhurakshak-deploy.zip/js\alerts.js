/**
 * BhuRakshak Multi-Channel Early Warning & CAP Dispatch System
 * Smart India Hackathon 2026 - Problem Statement 26001
 * Team: Codebreakers | Organization: MDoNER & NDMA
 * 
 * Complies with National Disaster Management Authority (NDMA) Common Alerting Protocol (CAP).
 * Supports 5 regional languages (English, Hindi, Assamese, Bengali, Mizo).
 * Integrates Web Audio API emergency siren and Web Speech API IVR voice broadcast.
 */

const AlertSystem = (function () {
  let audioCtx = null;
  let sirenOscillator = null;
  let sirenGain = null;
  let lfoNode = null;
  let isSirenPlaying = false;
  let autoStopTimer = null;

  // Multilingual Emergency Alert Templates
  const TRANSLATIONS = {
    en: {
      langName: "English",
      speechLang: "en-IN",
      criticalTitle: "CRITICAL LANDSLIDE RED ALERT",
      criticalMsg: "IMMEDIATE EVACUATION ADVISORY: High slope instability and impending debris flow detected in {location}. Highway {highway} is closed. Move immediately to {shelter}. Avoid riverside slopes. - SDMA & MDoNER Disaster Cell",
      warningTitle: "LANDSLIDE SEVERE WARNING",
      warningMsg: "HEAVY PRECIPITATION ALERT: Saturated soil and slope creep observed near {location}. Restrict vehicular movement on {highway}. Response teams deployed. - Disaster Management Authority",
      vmsHeader: "DANGER: LANDSLIDE HAZARD AHEAD",
      vmsSub: "HIGHWAY BLOCKED AT KM 42 | DIVERT VIA BYPASS"
    },
    hi: {
      langName: "हिन्दी (Hindi)",
      speechLang: "hi-IN",
      criticalTitle: "अत्यंत गंभीर भूस्खलन रेड अलर्ट",
      criticalMsg: "तत्काल निकासी परामर्श: {location} में भारी ढलान अस्थिरता और तीव्र भूस्खलन का खतरा पाया गया है। राष्ट्रीय राजमार्ग {highway} बंद है। तुरंत निकटतम सुरक्षित आश्रय {shelter} की ओर जाएं। - पूर्वोत्तर क्षेत्र विकास मंत्रालय एवं राज्य आपदा प्राधिकरण",
      warningTitle: "भूस्खलन गंभीर चेतावनी",
      warningMsg: "सतर्कता सूचना: {location} के पास अत्यधिक वर्षा के कारण मिट्टी खिसकने की संभावना है। {highway} पर यात्रा स्थगित करें। बचाव दल तैनात हैं।",
      vmsHeader: "सावधान: आगे भारी भूस्खलन खतरा",
      vmsSub: "सड़क अवरुद्ध | कृपया वैकल्पिक मार्ग अपनाएं"
    },
    as: {
      langName: "অসমীয়া (Assamese)",
      speechLang: "bn-IN", // Fallback to Bengali voice engine for Assamese phonetics if as-IN unavailable
      criticalTitle: "জৰুৰী ভূমিস্খলন ৰেড এলাৰ্ট",
      criticalMsg: "অবিলম্বে স্থান ত্যাগৰ নিৰ্দেশ: {location} অঞ্চলত প্ৰচণ্ড বৰষুণৰ ফলত ভয়ংকৰ ভূমিস্খলনৰ সম্ভাৱনা ধৰা পৰিছে। {highway} বন্ধ কৰা হৈছে। লগে লগে সুৰক্ষিত আশ্ৰয়স্থল {shelter} লৈ যাওক। - দুৰ্যোগ ব্যৱস্থাপনা কৰ্তৃপক্ষ",
      warningTitle: "ভূমিস্খলন সতৰ্কবাৰ্তা",
      warningMsg: "সতৰ্কতা জাননী: {location} অঞ্চলত মাটি ধহি যোৱাৰ সম্ভাৱনা বৃদ্ধি পাইছে। {highway} পথত যাতায়ত সীমিত কৰক।",
      vmsHeader: "সাৱধান: ভূমিস্খলনৰ আশংকা",
      vmsSub: "পথ বন্ধ | অন্য বিকল্প পথ ব্যৱহাৰ কৰক"
    },
    bn: {
      langName: "বাংলা (Bengali)",
      speechLang: "bn-IN",
      criticalTitle: "জরুরি ভূমিধস লাল সতর্কতা",
      criticalMsg: "অবিলম্বে স্থান ত্যাগ করার নির্দেশ: {location} অঞ্চলে পাহাড়ি ঢাল ধসের মারাত্মক আশঙ্কা তৈরি হয়েছে। {highway} সম্পূর্ণ বন্ধ। অবিলম্বে নিকটবর্তী নিরাপদ কেন্দ্র {shelter} এ আশ্রয় নিন। - রাজ্য বিপর্যয় মোকাবিলা বাহিনী",
      warningTitle: "ভূমিধস কমলা সতর্কতা",
      warningMsg: "সতর্কবার্তা: {location} সংলগ্ন পাহাড়ি এলাকায় মাটি আলগা হয়ে যাওয়ার লক্ষণ দেখা গেছে। অপ্রয়োজনীয় ভ্রমণ এড়িয়ে চলুন।",
      vmsHeader: "বিপদ: সামনে ভূমিধস",
      vmsSub: "হাইওয়ে অবরুদ্ধ | নিরাপদ দূরত্বে অবস্থান করুন"
    },
    mizo: {
      langName: "Mizo ṭawng (Mizo)",
      speechLang: "en-IN",
      criticalTitle: "CHHIATRUPNA LEILOK VAU KHANNA SEN",
      criticalMsg: "HRIATTIRNA HMANHMAWHTHLAK: {location} ah leimin hlauhawm tak thleng thut thei a nih avangin inthiarfihlim vat rawh u. {highway} chu khar a ni. Himna hmun {shelter} pan nghal rawh u. - Disaster Management Authority",
      warningTitle: "LEIMIN VAU KHANNA",
      warningMsg: "Ruahsur nasat avangin {location} bulah lei tawlh theihna a sang hle. {highway} kawngah fimkhur rawh u.",
      vmsHeader: "VAU KHANNA: LEIMIN HLAUHAWM",
      vmsSub: "KAWNG A PING | DANG LAM RAWH U"
    }
  };

  let currentLang = "en";

  /**
   * Generates localized CAP message based on current risk level and location
   */
  function generateAlertContent(level, location = "Cherrapunji - Sohra Escarpment", highway = "NH-10 / SH-5", shelter = "Sohra Community Relief Center") {
    const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    const isCritical = level === "CRITICAL";

    const title = isCritical ? dict.criticalTitle : dict.warningTitle;
    let text = isCritical ? dict.criticalMsg : dict.warningMsg;

    text = text.replace("{location}", location)
               .replace("{highway}", highway)
               .replace("{shelter}", shelter);

    return {
      title,
      text,
      language: dict.langName,
      speechCode: dict.speechLang,
      vmsHeader: dict.vmsHeader,
      vmsSub: dict.vmsSub,
      timestamp: new Date().toLocaleTimeString(),
      capId: "CAP-IN-MDONER-2026-" + Math.floor(100000 + Math.random() * 900000)
    };
  }

  /**
   * Synthesize realistic emergency siren via Web Audio API
   */
  function toggleEmergencySiren(forceState = null) {
    if (forceState !== null) {
      if (forceState && !isSirenPlaying) playSirenSound();
      else if (!forceState && isSirenPlaying) stopSirenSound();
      return isSirenPlaying;
    }

    if (isSirenPlaying) {
      stopSirenSound();
    } else {
      playSirenSound();
    }
    return isSirenPlaying;
  }

  function playSirenSound(autoStopSeconds = 8) {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!audioCtx) audioCtx = new AudioCtx();
      if (audioCtx.state === 'suspended') audioCtx.resume();

      if (isSirenPlaying) stopSirenSound();

      sirenGain = audioCtx.createGain();
      sirenGain.gain.setValueAtTime(0.18, audioCtx.currentTime); // Controlled volume
      sirenGain.connect(audioCtx.destination);

      sirenOscillator = audioCtx.createOscillator();
      sirenOscillator.type = 'sawtooth';
      sirenOscillator.frequency.setValueAtTime(650, audioCtx.currentTime);

      // Low frequency oscillator for pitch sweep
      lfoNode = audioCtx.createOscillator();
      lfoNode.frequency.setValueAtTime(0.65, audioCtx.currentTime);
      const lfoGain = audioCtx.createGain();
      lfoGain.gain.setValueAtTime(320, audioCtx.currentTime); // Sweep between 450Hz and 970Hz
      
      lfoNode.connect(sirenOscillator.frequency);
      sirenOscillator.connect(sirenGain);

      lfoNode.start();
      sirenOscillator.start();
      isSirenPlaying = true;
      updateSirenUI(true);

      // Auto-stop after specified seconds so evaluator ears aren't overwhelmed
      if (autoStopTimer) clearTimeout(autoStopTimer);
      if (autoStopSeconds > 0) {
        autoStopTimer = setTimeout(() => {
          stopSirenSound();
        }, autoStopSeconds * 1000);
      }
    } catch (e) {
      console.warn("AudioContext error:", e);
      isSirenPlaying = false;
      updateSirenUI(false);
    }
  }

  function stopSirenSound() {
    if (autoStopTimer) {
      clearTimeout(autoStopTimer);
      autoStopTimer = null;
    }
    if (sirenOscillator) {
      try {
        sirenOscillator.stop();
        sirenOscillator.disconnect();
      } catch (e) {}
      sirenOscillator = null;
    }
    if (lfoNode) {
      try {
        lfoNode.stop();
        lfoNode.disconnect();
      } catch (e) {}
      lfoNode = null;
    }
    isSirenPlaying = false;
    updateSirenUI(false);
  }

  function updateSirenUI(playing) {
    const btn = document.getElementById('btn-toggle-siren');
    const badge = document.getElementById('siren-status-badge');
    if (btn) {
      btn.innerHTML = playing 
        ? '<i data-lucide="volume-x" class="w-4 h-4 mr-1.5 text-rose-400"></i> Mute Siren'
        : '<i data-lucide="volume-2" class="w-4 h-4 mr-1.5 text-amber-400"></i> Sound Siren';
    }
    if (badge) {
      badge.textContent = playing ? "SIREN ACTIVE (AUDIO ON)" : "SIREN STANDBY";
      badge.className = playing ? "badge-critical px-2 py-0.5 rounded text-[10px] font-mono animate-pulse" : "badge-normal px-2 py-0.5 rounded text-[10px] font-mono";
    }
    if (window.lucide) window.lucide.createIcons();
  }

  /**
   * Speak out the alert using Web Speech Synthesis API
   */
  function broadcastVoiceAlert(customText = null) {
    if (!('speechSynthesis' in window)) {
      alert("Text-to-speech not supported in this browser.");
      return;
    }

    window.speechSynthesis.cancel();
    const alertData = generateAlertContent("CRITICAL");
    const textToSpeak = customText || alertData.text;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    const targetCode = alertData.speechCode;
    const match = voices.find(v => v.lang.startsWith(targetCode.substring(0, 2)));
    if (match) utterance.voice = match;

    window.speechSynthesis.speak(utterance);

    if (window.App) {
      window.App.showNotificationToast(`🔊 Playing CAP IVR Voice Broadcast in ${alertData.language}...`);
    }
  }

  function setLanguage(langKey) {
    if (TRANSLATIONS[langKey]) {
      currentLang = langKey;
    }
  }

  function getCurrentLanguage() {
    return currentLang;
  }

  return {
    TRANSLATIONS,
    setLanguage,
    getCurrentLanguage,
    generateAlertContent,
    toggleEmergencySiren,
    playSirenSound,
    stopSirenSound,
    broadcastVoiceAlert,
    isSirenActive: () => isSirenPlaying
  };
})();

window.AlertSystem = AlertSystem;
